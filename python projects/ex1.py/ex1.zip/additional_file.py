#################################################################
# FILE : additional_file.py
# WRITER : orin levi , orin.levi , 206440075
# EXERCISE : intro2cs2 ex1 2021
# DESCRIPTION: A simple program that print the "secret function"
# STUDENTS I DISCUSSED THE EXERCISE WITH: ori
# NOTES: its my first program to write so i needed help from other students
#################################################################

def secret_function():
  """adding the secret function"""
  print('My username is orin.levi and I know I must read the submission response.')


if __name__ == "__main__":
  secret_function()
