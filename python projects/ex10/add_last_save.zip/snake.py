from copy import deepcopy
from typing import List


#################################################################
# FILE : snake.py
# WRITER : orin levi , orin.levi , 206440075 and Pnina_ei Pnina 212125678
# EXERCISE : intro2cs2 ex10 2021
# DESCRIPTION: class Snake
# STUDENTS I DISCUSSED THE EXERCISE WITH: Orin Levi, Pnina Eisenbach.
#################################################################

class Node:
	"""this class is the main of the objects. its create the snake and show
	the connection between the snake and the apples and the bombs. """

	def __init__(self, coordinate, _next=None, _prev=None):
		self.__coordinate = coordinate
		self.__next = _next
		self.__prev = _prev

	def get_coordinate(self) -> tuple:
		return self.__coordinate

	def set_next(self, _next):
		self.__next = _next

	def set_prev(self, prev):
		self.__prev = prev

	def get_next(self):
		return self.__next

	def get_prev(self):
		return self.__prev


class Snake:
	def __init__(self, direction="Up"):
		self.__head = None
		self.__tail = None
		self.__color = "black"
		self.__direction = direction
		self.__length = 0
		self.__length_to_add = 0
		self.__tail_direction = direction

	def add_first(self, cor: tuple):
		vertebra = Node(cor)
		if self.__head is None:
			self.__tail = vertebra
		elif cor != self.get_head_coordinate():
			vertebra.set_prev(self.__head)
			self.__head.set_next(vertebra)
		else:
			return
		self.__head = vertebra
		self.__length += 1

	def add_last(self, cor):
		vertebra = Node(cor)
		if self.__tail is None:
			self.__head = vertebra
		else:
			vertebra.set_next(self.__tail)
			self.__tail.set_prev(vertebra)
		self.__tail = vertebra
		self.__length += 1

	def remove_last(self):
		prev_tail = self.__tail
		if self.__tail:
			self.__tail = self.__tail.get_next()
			prev_tail.set_next(None)
			if self.__tail is None:
				self.__head = None
				self.__length = 0
			else:
				self.__tail.set_prev(None)
			self.__length -= 1
		else:
			self.__head = self.__tail = None

	def get_head_coordinate(self):
		return self.__head.get_coordinate()

	def get_tail_coordinate(self):
		return self.__tail.get_coordinate()

	def set_direction(self, direction: str):
		self.__direction = direction

	def get_direction(self):
		return self.__direction

	def set_tail_direction(self):
		x, y = self.get_head_coordinate()
		a, b = self.get_tail_coordinate()
		if x == a or y == b:
			self.__tail_direction = self.get_direction()

	def get_tail_direction(self):
		return self.__tail_direction

	def get_color(self):
		return self.__color

	def get_snake_coordinate(self) -> List[tuple]:
		coordinate = []
		vertebra = self.__head
		while vertebra:
			coordinate.append(vertebra.get_coordinate())
			vertebra = vertebra.get_prev()
		return deepcopy(coordinate)

	def get_snake_length(self):
		return self.__length

	def set_add_to_snake_length(self, addition):
		self.__length_to_add += addition

	def __get_length_to_add(self):
		return self.__length_to_add

	def __reduce_length_to_add(self):
		self.__length_to_add -= 1

	def move_the_snake(self, cell):
		self.add_first(cell)
		if self.__get_length_to_add() == 0:
			self.remove_last()
		else:
			self.__reduce_length_to_add()

	def snake_hit_himself(self):
		snake_coordinate = self.get_snake_coordinate()
		if snake_coordinate.count(self.get_head_coordinate()) > 1:
			return True

