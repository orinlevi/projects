
from game_display import GameDisplay
from game import *


#################################################################
# FILE : snake_main.py
# WRITER : orin levi , orin.levi , 206440075 and Pnina_ei Pnina 212125678
# EXERCISE : intro2cs2 ex10 2021
# DESCRIPTION: the main loop for the game
# STUDENTS I DISCUSSED THE EXERCISE WITH: Orin Levi, Pnina Eisenbach.
#################################################################


def display_elements(gd: GameDisplay, game: Game, do_snake_hit_bomb: bool):

	# shows the elements of the game
	gd.show_score(game.get_score())  # score

	snake_cor = []  # snake
	if do_snake_hit_bomb:
		snake_cor = [cor for cor in game.get_snake().get_snake_coordinate()
		             if cor not in game.get_bomb().get_coordinate()]
	else:
		snake_cor = game.get_snake().get_snake_coordinate()
	for cell in snake_cor:
		a, b = cell
		gd.draw_cell(a, b, game.get_snake().get_color())

	for boom_cor in game.get_bomb().get_coordinate():  # bomb
		boom_x, boom_y = boom_cor
		gd.draw_cell(boom_x, boom_y, game.get_bomb().get_color())

	for cor, apple in game.get_apples().items():  # apples
		_x, _y = cor
		gd.draw_cell(_x, _y, apple.get_color())


def main_loop(gd: GameDisplay) -> None:
	"""this function is the main function that run the game. the rounds of
	the game are shown here. the initiate of the objects start before the
	rounds of the game. the apple located in random places and also the
	bomb. the snake is located on the (10, 10) cell"""

	game = Game()
	display_elements(gd, game, False)
	gd.end_round()

	while True:
		key_clicked = gd.get_key_clicked()  # updates_snake
		game.key_clicked_change_snake_direction(key_clicked)
		game.key_clicked_move_snake()

		game.bomb_explosion()  # updates_bomb

		game.check_apples_to_relocate_and_score()  # updates_score_from_apples
		if game.is_board_full():  # checks_empty_space_in_board
			display_elements(gd, game, game.do_snake_hit_bomb())
			gd.end_round()
			break
		game.relocate_apples()  # updates_apples

		display_elements(gd, game, game.do_snake_hit_bomb())

		# checks_disqualification
		if game.do_snake_hit_himself() or game.do_snake_hit_bomb() or \
			game.if_snake_out_of_range():
			gd.end_round()
			break

		gd.end_round()


if __name__ == '__main__':
	gd = GameDisplay()
	main_loop(gd)
