#################################################################
# FILE : apple.py
# WRITER : orin levi , orin.levi , 206440075 and Pnina_ei Pnina 212125678
# EXERCISE : intro2cs2 ex10 2021
# DESCRIPTION: class Apple
# STUDENTS I DISCUSSED THE EXERCISE WITH: Orin Levi, Pnina Eisenbach.
#################################################################

class Apple:
	"""this class create the apple object. the class has three methods
	that's are giving back the
	apple's attributes. the contracture initiate the coordinates of the
	apple, the score and the color of the cell of which the apple in it  """

	def __init__(self, coordinate, score):
		self.__coordinate = coordinate
		self.__score = score
		self.__color = "green"

	def get_coordinate(self):
		"""
		:return coordinates
		the methods return the coordinates of the apple
		"""
		return self.__coordinate

	def get_color(self):
		"""
		:return color of the apple
		the methods return the color of the apple
		"""
		return self.__color

	def get_score(self):
		"""
		:return score
		the methods return the score of the apple
		"""
		return self.__score
