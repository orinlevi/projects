
from game_display import GameDisplay
from game import *


#################################################################
# FILE : snake_main.py
# WRITER : orin levi , orin.levi , 206440075 and Pnina_ei Pnina 212125678
# EXERCISE : intro2cs2 ex10 2021
# DESCRIPTION: the main loop for the game
# STUDENTS I DISCUSSED THE EXERCISE WITH: Orin Levi, Pnina Eisenbach.
#################################################################


def display_elements(gd: GameDisplay, game: Game, do_snake_hit_bomb: bool):

	# shows the elements of the game
	gd.show_score(game.get_score())  # score

	snake_cor = []  # snake
	if do_snake_hit_bomb:
		snake_cor = [cor for cor in game.get_snake().get_snake_coordinate()
		             if cor not in game.get_bomb().get_coordinate()]
	else:
		snake_cor = game.get_snake().get_snake_coordinate()
	for cell in snake_cor:
		a, b = cell
		gd.draw_cell(a, b, game.get_snake().get_color())

	for boom_cor in game.get_bomb().get_coordinate():  # bomb
		boom_x, boom_y = boom_cor
		gd.draw_cell(boom_x, boom_y, game.get_bomb().get_color())

	for cor, apple in game.get_apples().items():  # apples
		_x, _y = cor
		gd.draw_cell(_x, _y, apple.get_color())


def main_loop(gd: GameDisplay) -> None:
	"""this function is the main function that run the game. the rounds of
	the game are shown here. the initiate of the objects start before the
	rounds of the game. the apple located in random places and also the
	bomb. the snake is located on the (10, 10) cell"""

	game = Game()
	display_elements(gd, game, False)
	gd.end_round()

	while True:
		key_clicked = gd.get_key_clicked()  # updates_snake
		game.key_clicked_change_snake_direction(key_clicked)
		game.key_clicked_move_snake()

		if not (game.do_snake_hit_himself() or game.do_snake_hit_bomb()):
			game.bomb_explosion()  # updates_bomb

		game.check_apples_to_relocate_and_score()  # updates_score_from_apples
		if game.is_board_full():  # checks_empty_space_in_board
			display_elements(gd, game, game.do_snake_hit_bomb())
			gd.end_round()
			# print("orin_reuven")
			break
		game.relocate_apples()  # updates_apples

		display_elements(gd, game, game.do_snake_hit_bomb())

		# checks_disqualification
		if game.do_snake_hit_himself() or game.do_snake_hit_bomb() or \
			game.if_snake_out_of_range():
			gd.end_round()
			break

		gd.end_round()


# test_6 = [(0, {(20, 15): 'black', (20, 14): 'black', (20, 13): 'black',
#                 (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (20, 16): 'black', (20, 15): 'black', (20, 14): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (20, 17): 'black', (20, 16): 'black', (20, 15): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (20, 18): 'black', (20, 17): 'black', (20, 16): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (20, 19): 'black', (20, 18): 'black', (20, 17): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (21, 19): 'black', (20, 19): 'black', (20, 18): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (22, 19): 'black', (21, 19): 'black', (20, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (23, 19): 'black', (22, 19): 'black', (21, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (24, 19): 'black', (23, 19): 'black', (22, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (25, 19): 'black', (24, 19): 'black', (23, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (26, 19): 'black', (25, 19): 'black', (24, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (27, 19): 'black', (26, 19): 'black', (25, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (28, 19): 'black', (27, 19): 'black', (26, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (29, 19): 'black', (28, 19): 'black', (27, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (30, 19): 'black', (29, 19): 'black', (28, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (31, 19): 'black', (30, 19): 'black', (29, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (32, 19): 'black', (31, 19): 'black', (30, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (33, 19): 'black', (32, 19): 'black', (31, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (34, 19): 'black', (33, 19): 'black', (32, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (34, 20): 'black', (34, 19): 'black', (33, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (34, 21): 'black', (34, 20): 'black', (34, 19): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (34, 22): 'black', (34, 21): 'black', (34, 20): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (34, 23): 'black', (34, 22): 'black', (34, 21): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (33, 23): 'black', (34, 23): 'black', (34, 22): 'black', (30, 22): 'red'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (32, 23): 'black', (33, 23): 'black', (34, 23): 'black', (30, 22): 'orange'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (31, 23): 'black', (32, 23): 'black', (33, 23): 'black', (30, 23): 'orange', (29, 22): 'orange', (30, 21): 'orange', (31, 22): 'orange'}), (0, {(12, 2): 'green', (16, 26): 'green', (21, 8): 'green', (30, 23): 'orange', (31, 23): 'black', (32, 23): 'black', (29, 22): 'orange', (30, 21): 'orange', (31, 22): 'orange'})]
#
# test_6_actual = [(0, {(20, 15): 'black', (20, 14): 'black', (20, 13): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(20, 16): 'black', (20, 15): 'black', (20, 14): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(20, 17): 'black', (20, 16): 'black', (20, 15): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(20, 18): 'black', (20, 17): 'black', (20, 16): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(20, 19): 'black', (20, 18): 'black', (20, 17): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(21, 19): 'black', (20, 19): 'black', (20, 18): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(22, 19): 'black', (21, 19): 'black', (20, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(23, 19): 'black', (22, 19): 'black', (21, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(24, 19): 'black', (23, 19): 'black', (22, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(25, 19): 'black', (24, 19): 'black', (23, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(26, 19): 'black', (25, 19): 'black', (24, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(27, 19): 'black', (26, 19): 'black', (25, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(28, 19): 'black', (27, 19): 'black', (26, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(29, 19): 'black', (28, 19): 'black', (27, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(30, 19): 'black', (29, 19): 'black', (28, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(31, 19): 'black', (30, 19): 'black', (29, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(32, 19): 'black', (31, 19): 'black', (30, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(33, 19): 'black', (32, 19): 'black', (31, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(34, 19): 'black', (33, 19): 'black', (32, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(34, 20): 'black', (34, 19): 'black', (33, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(34, 21): 'black', (34, 20): 'black', (34, 19): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(34, 22): 'black', (34, 21): 'black', (34, 20): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(34, 23): 'black', (34, 22): 'black', (34, 21): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(33, 23): 'black', (34, 23): 'black', (34, 22): 'black', (30, 22): 'red', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(32, 23): 'black', (33, 23): 'black', (34, 23): 'black', (30, 22): 'orange', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(31, 23): 'black', (32, 23): 'black', (33, 23): 'black', (29, 22): 'orange', (31, 22): 'orange', (30, 23): 'orange', (30, 21): 'orange', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'}), (0, {(30, 23): 'black', (32, 23): 'black', (32, 22): 'orange', (30, 20): 'orange', (29, 21): 'orange', (28, 22): 'orange', (29, 23): 'orange', (31, 23): 'orange', (31, 21): 'orange', (30, 24): 'orange', (12, 2): 'green', (16, 26): 'green', (21, 8): 'green'})]
#
#
# test_3 =  [(0, {(20, 15): 'black', (20, 14): 'black', (20, 13): 'black', (29, 19): 'red', (8, 5): 'green', (21, 16): 'green', (38, 2): 'green'}), (0, {(8, 5): 'green', (21, 16): 'green', (38, 2): 'green', (20, 16): 'black', (20, 15): 'black', (20, 14): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (21, 16): 'black', (20, 16): 'black', (20, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (22, 16): 'black', (21, 16): 'black', (20, 16): 'black', (20, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 16): 'black', (22, 16): 'black', (21, 16): 'black', (20, 16): 'black', (20, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 16): 'black', (23, 16): 'black', (22, 16): 'black', (21, 16): 'black', (20, 16): 'black', (20, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (25, 16): 'black', (24, 16): 'black', (23, 16): 'black', (22, 16): 'black', (21, 16): 'black', (20, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (25, 15): 'black', (25, 16): 'black', (24, 16): 'black', (23, 16): 'black', (22, 16): 'black', (21, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 15): 'black', (25, 15): 'black', (25, 16): 'black', (24, 16): 'black', (23, 16): 'black', (22, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 15): 'black', (24, 15): 'black', (25, 15): 'black', (25, 16): 'black', (24, 16): 'black', (23, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 16): 'black', (23, 15): 'black', (24, 15): 'black', (25, 15): 'black', (25, 16): 'black', (24, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 17): 'black', (23, 16): 'black', (23, 15): 'black', (24, 15): 'black', (25, 15): 'black', (25, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 18): 'black', (23, 17): 'black', (23, 16): 'black', (23, 15): 'black', (24, 15): 'black', (25, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 19): 'black', (23, 18): 'black', (23, 17): 'black', (23, 16): 'black', (23, 15): 'black', (24, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (23, 17): 'black', (23, 16): 'black', (23, 15): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 20): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (23, 17): 'black', (23, 16): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 19): 'black', (24, 20): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (23, 17): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 18): 'black', (24, 19): 'black', (24, 20): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 18): 'black', (24, 18): 'black', (24, 19): 'black', (24, 20): 'black', (23, 20): 'black', (23, 19): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 19): 'black', (23, 18): 'black', (24, 18): 'black', (24, 19): 'black', (24, 20): 'black', (23, 20): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (24, 18): 'black', (24, 19): 'black', (24, 20): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 21): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (24, 18): 'black', (24, 19): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 22): 'black', (23, 21): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (24, 18): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (23, 23): 'black', (23, 22): 'black', (23, 21): 'black', (23, 20): 'black', (23, 19): 'black', (23, 18): 'black', (29, 19): 'red'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (24, 23): 'black', (23, 23): 'black', (23, 22): 'black', (23, 21): 'black', (23, 20): 'black', (23, 19): 'black', (29, 19): 'orange'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (25, 23): 'black', (24, 23): 'black', (23, 23): 'black', (23, 22): 'black', (23, 21): 'black', (23, 20): 'black', (29, 20): 'orange', (28, 19): 'orange', (29, 18): 'orange', (30, 19): 'orange'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (26, 23): 'black', (25, 23): 'black', (24, 23): 'black', (23, 23): 'black', (23, 22): 'black', (23, 21): 'black', (29, 21): 'orange', (30, 20): 'orange', (27, 19): 'orange', (28, 20): 'orange', (29, 17): 'orange', (28, 18): 'orange', (31, 19): 'orange', (30, 18): 'orange'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (27, 23): 'black', (26, 23): 'black', (25, 23): 'black', (24, 23): 'black', (23, 23): 'black', (23, 22): 'black', (29, 22): 'orange', (30, 21): 'orange', (31, 20): 'orange', (26, 19): 'orange', (27, 20): 'orange', (28, 21): 'orange', (29, 16): 'orange', (28, 17): 'orange', (27, 18): 'orange', (32, 19): 'orange', (31, 18): 'orange', (30, 17): 'orange'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (28, 23): 'black', (27, 23): 'black', (26, 23): 'black', (25, 23): 'black', (24, 23): 'black', (23, 23): 'black', (29, 23): 'orange', (30, 22): 'orange', (31, 21): 'orange', (32, 20): 'orange', (25, 19): 'orange', (26, 20): 'orange', (27, 21): 'orange', (28, 22): 'orange', (29, 15): 'orange', (28, 16): 'orange', (27, 17): 'orange', (26, 18): 'orange', (33, 19): 'orange', (32, 18): 'orange', (31, 17): 'orange', (30, 16): 'orange'}), (4, {(8, 5): 'green', (38, 2): 'green', (35, 29): 'green', (29, 23): 'orange', (28, 23): 'black', (27, 23): 'black', (26, 23): 'black', (25, 23): 'black', (24, 23): 'black', (30, 22): 'orange', (31, 21): 'orange', (32, 20): 'orange', (25, 19): 'orange', (26, 20): 'orange', (27, 21): 'orange', (28, 22): 'orange', (29, 15): 'orange', (28, 16): 'orange', (27, 17): 'orange', (26, 18): 'orange', (33, 19): 'orange', (32, 18): 'orange', (31, 17): 'orange', (30, 16): 'orange'})]
#
#
# def main_loop(gd: GameDisplay):
# 	for frame in test_6:
# 		for coord, color in frame[1].items():
# 			gd.draw_cell(coord[0], coord[1], color)
# 		gd.end_round()


if __name__ == '__main__':
	gd = GameDisplay()
	main_loop(gd)
